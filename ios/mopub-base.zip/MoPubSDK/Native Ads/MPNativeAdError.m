//
//  MPNativeAdError.m
//  Copyright (c) 2013 MoPub. All rights reserved.
//

#import "MPNativeAdError.h"

NSString * const MoPubNativeAdsSDKDomain = @"com.mopub.nativeads";

NSString * const MPNativeAdErrorContentDisplayErrorReasonKey = @"contentDisplayErrorReason";
